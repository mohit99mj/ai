# backend/app/core/config.py

class Settings:
    PROJECT_NAME: str = "AI Resume Builder Pro"
    PROJECT_VERSION: str = "1.0.0"
    API_V1_STR: str = "/api/v1"

settings = Settings()