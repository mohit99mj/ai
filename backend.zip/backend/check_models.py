# backend/check_models.py
import os
from google import genai
from dotenv import load_dotenv

load_dotenv()
api_key = os.getenv("GEMINI_API_KEY")

if not api_key:
    print("❌ Error: API Key not found in .env file")
else:
    print(f"🔑 Key Found! Checking models with Google...")
    
    try:
        client = genai.Client(api_key=api_key)
        # Models list karo
        print("\n👇 AVAILABLE MODELS (Copy one of these):")
        for model in client.models.list():
            if "generateContent" in model.supported_actions:
                print(f"✅ {model.name}")
                
    except Exception as e:
        print(f"❌ Error: {e}")